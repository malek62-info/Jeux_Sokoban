
package model;


public class plus extends Case{
    
    public plus(int x, int y) {
        super(x, y, true, false);
    }
    
    public String toString(){
        return "+";
    }
}
