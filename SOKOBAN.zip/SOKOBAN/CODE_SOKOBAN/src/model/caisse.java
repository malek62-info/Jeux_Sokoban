
package model;


public class caisse  extends Case {
    private int x;
    private int y;
    
    public caisse(int x,int y){
       super(x,y,true,false);
    }

  
     public String toString(){
          return "$";

     } 
    
}
