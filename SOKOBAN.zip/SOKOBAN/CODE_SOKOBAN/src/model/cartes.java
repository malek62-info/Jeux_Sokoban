
package model;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import static java.util.Collections.list;
import vuetext.*;

public class cartes  {
       public  Map<Character, Object> phonebook = new HashMap<Character, Object>();
        private int i;
        Scanner sc=new Scanner(System.in);

        private int  cpt=0;
        private int x,y;
       Case tab[][]; 
       ArrayList<Case> l =new ArrayList<>();
       File f1=new File("");
       String chaine="";
       int[] tab2=new int[2];//pour stocké la posiotion de joueur
       ArrayList <Object> tab1=new ArrayList<Object>();
       Lecture lec;
       private int nb1,nb2;
       String [] ch1=new String[nb2] ;
   public cartes(File f , String ch1[],int nb1,int nb2) throws FileNotFoundException{
        this.nb1=nb1;
        this.nb2=nb2;
        tab =new Case[nb1][nb2];  

         lec=new Lecture(nb1,nb2,f,ch1);
         
         for(i=0;i<ch1.length;i++){
             this.chaine=chaine+ch1[i];
         }
         System.out.println("la chaine est de aille de "+chaine);
         
         

     }
      
      
      public Case[][] remplir_tab(){
        phonebook.put('$',new caisse(0,0));
        phonebook.put('#',new murs(0,0));
        phonebook.put('@',new joueur(0,0));
        phonebook.put('.',new patern(0,0));
        phonebook.put('/',new sol(0,0));
        phonebook.put(' ',new chemin(0,0));

        
        int k=0;
        for(i=0;i<nb1;i++){
            for(int j=0;j<nb2;j++){
            if(phonebook.containsKey(this.chaine.charAt(k))){
                tab[i][j]=(Case) phonebook.get((char )chaine.charAt(k));
                k+=1;
            }
        }}
        return tab;
      }
    ///////////methode pour Afficher la map
    public void afficher(){
        for(i=0;i<nb1;i++){
            for(int j=0;j<nb2;j++){
            System.out.print(tab[i][j].toString()+"  ");

        }
                        System.out.println("\n");

        }
    
    }    /////////// fin methode pour Afficher la map

    
        ///////////verifier le contour de joueur

    public void verifier_jouer(){
        int i,j;
        for(i=0;i<4;i++){
            for(j=0;j<nb2;j++){
                if(tab[i][j].toString()=="@" || tab[i][j].toString()=="*"){
                    tab1.add(tab[i+1][j]);
                    tab1.add(tab[i+2][j]);
                    tab1.add(tab[i][j+1]);
                    tab1.add(tab[i][j+2]);
                    tab1.add(tab[i-1][j]);
                    tab1.add(tab[i-2][j]);
                    tab1.add(tab[i][j-1]);
                    tab1.add(tab[i][j-2]);
                }
            }
        }
       for(i=0;i<tab1.size();i++){
           System.out.println(tab1.get(i));
       }
    }        /////////// fin de verifier le contour de joueur

    
    ////// methode pour savoir c'est je peut deplacr sur une case ou non
   public boolean marché_dessus(Case c){
       if(c.getDeplassable()){
           return true;
       }
       return false;  
   } 
       ////// fin methode pour savoir c'est je peut deplacr sur une case ou non

   
   
   ///methode pour récupiré la position du joueurs
   public int[] position_joueur(int []tab2){
       int i,j;
       tab2[0]=0;
       tab2[1]=0;
       for(i=0;i<nb1;i++){
           for(j=0;j<nb2;j++){
               if(tab[i][j].toString()=="@" ||tab[i][j].toString()=="*"){
                   tab2[0]=i;
                   tab2[1]=j;
               }
           }
         

       }
       return tab2;
      
   }
      ///fin methode pour récupiré la position du joueurs

   

//// methode pour savoire c'sst case peut se deplacer ou non
   public boolean peut_deplacer(int i,int j){
        boolean res=false;
        if(tab[i][j].isMarche_dessus()){
           res=true;
       }
       else{
           if(tab[i][j].getDeplassable()){
               if(tab[i][j].isMarche_dessus())
                   res=true;
           }
       }
       return res;
   }
   //// fin methode pour savoire c'sst une case peut se deplacer ou non

 //////// methode pour verifier la possibilité de deplacer le joueur a droit 
   public boolean deplaccer_droit(){

              boolean res=false;

              int[] tab2=new int[2];
              this.position_joueur(tab2);
       if(tab[tab2[0]][tab2[1]+1].isMarche_dessus()){
           res=true;
       }
       else{
           if(tab[tab2[0]][tab2[1]+1].getDeplassable()){
               if(tab[tab2[0]][tab2[1]+2].isMarche_dessus())
                   res=true;
           }
       }
       return res;
   }
     //////// fin methode pour verifier la possibilité de deplacer le joueur a droit 

   
   
   
    //////// methode pour verifier la possibilité de deplacer le joueur a gauche 

   public boolean deplaccer_gauche(){
       boolean res=false;
       int[] tab2=new int[2];
              this.position_joueur(tab2);
       if(tab[tab2[0]][tab2[1]-1].isMarche_dessus()){
           res= true;
       }
       else{
           if(tab[tab2[0]][tab2[1]-1].getDeplassable()){
               if(tab[tab2[0]][tab2[1]-2].isMarche_dessus())
                   res= true;
           }
       }
       return res;
   }
   
       ////////fin  methode pour verifier la possibilité de deplacer le joueur a gauche 

    
   
   
       //////// methode pour verifier la possibilité de deplacer le joueur en haut 

   public boolean deplaccer_en_haut(){
         boolean res=false;
       int[] tab2=new int[2];
              this.position_joueur(tab2);
       if(tab[tab2[0]-1][tab2[1]].isMarche_dessus()){
           res= true;
       }
       else{
           if(tab[tab2[0]-1][tab2[1]].getDeplassable()){
               if(tab[tab2[0]-2][tab2[1]].isMarche_dessus())
                   res= true;
           }
       }
       return res;
   }
          //////// fin methode pour verifier la possibilité de deplacer le joueur aen haut 

   
          


//////// methode pour verifier la possibilité de deplacer le joueur aen bas 

      public boolean deplaccer_en_bas(){
          boolean res=false;
       int[] tab2=new int[2];
              this.position_joueur(tab2);
       if(tab[tab2[0]+1][tab2[1]].isMarche_dessus()){
           res= true;
       }
       else{
           if(tab[tab2[0]+1][tab2[1]].getDeplassable()){
               if(tab[tab2[0]+2][tab2[1]].isMarche_dessus())
                   res= true;
           }
       }
       return res;
   }
               //////// fin methode pour verifier la possibilité de deplacer le joueur aen bas 

      
      
      ///// la methode pour géré les case de deplasement s'il il a lieu
      public ArrayList<Case> les_cas(ArrayList<Case> l){
          ArrayList<Case> l2=new ArrayList<>();
          
           
           
          if(l.get(0).toString()=="*" && l.get(1).toString()=="$" && l.get(2).toString()=="." ){
                l2.add(new patern(0,0));
                l2.add(new joueur(0,0));
                l2.add(new plus(0,0));
           }else{
              
           if(l.get(0).toString()=="@" && l.get(1).toString()=="+" && l.get(2).toString()==" " ){
                l2.add(new chemin(0,0));
                l2.add(new etoile(0,0));
                l2.add(new caisse(0,0));
           }
           else{ 
            
            if(l.get(0).equals(new etoile(0,0)) && l.get(1).toString()=="$" && l.get(2).toString()==" " ){
                l2.add(new patern(0,0));
                l2.add(new joueur(0,0));
                l2.add(new caisse(0,0));
                
            }
            else{
         if(l.get(0).toString()=="*" && l.get(1).toString()=="+" && l.get(2).toString()==" " ){
                l2.add(new patern(0,0));
                l2.add(new etoile(0,0));
                l2.add(new caisse(0,0));
               
         }
         else{
          if(l.get(0).toString()=="*" && l.get(1).toString()=="+" && l.get(2).toString()=="." ){
                l2.add(new patern(0,0));
                l2.add(new etoile(0,0));
                l2.add(new plus(0,0));
         }
          
          else{
           if(l.get(0).toString()=="@" && l.get(1).toString()=="+" && l.get(2).toString()=="." ){
                l2.add(new chemin(0,0));
                l2.add(new etoile(0,0));
                l2.add(new plus(0,0));
                 
           }
          
           else{
           if(l.get(0).toString()=="@" && l.get(1).toString()=="$" && l.get(2).toString()=="." ){
                l2.add(new chemin(0,0));
                l2.add(new joueur(0,0));
                l2.add(new plus(0,0));
                                              
           }
                                              
            else{
            if(l.get(0).toString()=="@" && l.get(1).toString()=="$" && l.get(2).toString()=="#"){
                   l2.add( new joueur(0,0));
                   l2.add(new caisse(0,0));
                   l2.add(new murs(0,0));
            
            }
            else{
            if(l.get(0).toString()=="@" && l.get(1).toString()=="$" && l.get(2).toString()=="$"){
                   l2.add( new joueur(0,0));
                   l2.add(new caisse(0,0));
                   l2.add(new caisse(0,0));
               
            }
            else{
            if(l.get(0).toString()=="@" && l.get(1).toString()=="#"){
                    l2.add(new joueur(0,0));
                    l2.add( new murs(0,0));
          
            }    
                  
            else{    
                  
            if(l.get(0).toString()=="@" && l.get(1).toString()=="$" &&l.get(2).toString()=="." ){
                     l2.add( new chemin(0,0));
                     l2.add(new joueur(0,0));
                     l2.add(new caisse(0,0));
                      
            }
            
            else{
            if(l.get(0).toString()=="@" && l.get(1).toString()=="$" &&l.get(2).toString()==" " ){
                     l2.add( new chemin(0,0));
                     l2.add(new joueur(0,0));
                     l2.add(new caisse(0,0));
                   
            }
            
            else{
            if(l.get(0).toString()=="@" && l.get(1).toString()==" "){
                    l2.add(new chemin(0,0));
                    l2.add( new joueur(0,0));
                          
            }
                              
            else{
            if(l.get(0).toString()=="@" && l.get(1).toString()=="$" && l.get(2).toString()=="."){
                     l2.add(new chemin(0,0));
                     l2.add(new joueur(0,0));
                     l2.add(new caisse(0,0));

            }
                                  
            else{
            if(l.get(0).toString()=="*" && l.get(1).toString()=="." && l.get(2).toString()=="." ){
                     l2.add(new patern(0,0));
                     l2.add(new etoile(0,0));
                     l2.add(new patern(0,0));

            }
                                      
            else{
            if(l.get(0).toString()=="@" && l.get(1).toString()=="."){
                    l2.add(new chemin(0,0));
                    l2.add(new etoile(0,0));

            }
                                      
            else{
            if(l.get(0).toString()=="*" && l.get(1).toString()==" "){
                     l2.add(new patern(0,0));
                     l2.add(new joueur(0,0));
            
            }
                                           
            else{
            if(l.get(0).toString()=="*" && l.get(1).toString()=="."  ){
                    l2.add(new patern(0,0));
                    l2.add(new etoile(0,0));
                            
            }
            }
            
            }
            }}
            
            }
            }}}}}}}}}}}}
              
          return l2;



      }////////fin  methode pour verifier la possibilité de deplacer le joueur aen bas 

      
     ///// methode pour deplacer le robot vers l'adroit
   public void deplacer_robot_a_droit(){
        ArrayList<Case> l2=new ArrayList<>();
        this.position_joueur(tab2);
        ArrayList<Case> updated=new ArrayList<>();
        l.clear();
   
        boolean res =false;
      if(deplaccer_droit()){
          l.add(tab[tab2[0]][tab2[1]]);
          l.add(tab[tab2[0]][tab2[1]+1]);
          l.add(tab[tab2[0]][tab2[1]+2]);
          updated=this.les_cas(l);
          System.out.println(tab2[0]+" "+tab2[1]);
          System.out.println(tab[tab2[0]][tab2[1]]);
          System.out.println(tab[tab2[0]][tab2[1]-1]);
         
          
        tab[tab2[0]][tab2[1]]=updated.get(0);
        tab[tab2[0]][tab2[1]+1]=updated.get(1);
        if(updated.size()>=3){
        tab[tab2[0]][tab2[1]+2]=updated.get(2);
        }

         res=true;
      }
      
      this.afficher();
   
     
      
   }///// methode pour deplacer le robot vers l'adroit

   
        ///// methode pour deplacer le robot vers a gauche
   public void deplacer_robot_a_gauche(){
        ArrayList<Case> l2=new ArrayList<>();
        l.clear();
        this.position_joueur(tab2);
        ArrayList<Case> updated=new ArrayList<>();
        boolean res =false;
      if(deplaccer_gauche()){
         
          l.add(tab[tab2[0]][tab2[1]]);
          l.add(tab[tab2[0]][tab2[1]-1]);
          l.add(tab[tab2[0]][tab2[1]-2]);
          updated=this.les_cas(l);
         
          System.out.println(tab2[0]+" "+tab2[1]);
          System.out.println(tab[tab2[0]][tab2[1]]);
          System.out.println(tab[tab2[0]][tab2[1]-1]);
          System.out.println(tab[tab2[0]][tab2[1]-2]);
          System.out.println(l.get(0));
          System.out.println(l.get(1));
          System.out.println(l.get(2));
          
          tab[tab2[0]][tab2[1]]=updated.get(0);
        tab[tab2[0]][tab2[1]-1]=updated.get(1);
        if(updated.size()>=3){
        tab[tab2[0]][tab2[1]-2]=updated.get(2);

        }
        this.afficher();

      }
 
   }     ///// fin methode pour deplacer le robot vers a gauche

   
   
        ///// methode pour deplacer le robot vers en haut
    public void deplacer_robot_en_haut(){
         ArrayList<Case> l2=new ArrayList<>();
         l.clear();
         this.position_joueur(tab2);
         ArrayList<Case> updated=new ArrayList<>();
        boolean res =false;
      if(this.deplaccer_en_haut()){
         
          l.add(tab[tab2[0]][tab2[1]]);
          l.add(tab[tab2[0]-1][tab2[1]]);
          l.add(tab[tab2[0]-2][tab2[1]]);
          updated=this.les_cas(l);
         
          System.out.println(tab2[0]+" "+tab2[1]);
          System.out.println(tab[tab2[0]][tab2[1]]);
          System.out.println(tab[tab2[0]-1][tab2[1]]);
          System.out.println(tab[tab2[0]-2][tab2[1]]);
          System.out.println(l.get(0));
          System.out.println(l.get(1));
          System.out.println(l.get(2));
          
          tab[tab2[0]][tab2[1]]=updated.get(0);
        tab[tab2[0]-1][tab2[1]]=updated.get(1);
        if(updated.size()>=3){
        tab[tab2[0]-2][tab2[1]]=updated.get(2);

        }
        this.afficher();

      }
   }     /////fin  methode pour deplacer le robot vers en haut

    
    
         ///// methode pour deplacer le robot vers en bas

       public void deplacer_robot_en_bas(){
        ArrayList<Case> l2=new ArrayList<>();
        l.clear();
        this.position_joueur(tab2);
        ArrayList<Case> updated=new ArrayList<>();
        boolean res =false;
      if(this.deplaccer_en_bas()){
         
          l.add(tab[tab2[0]][tab2[1]]);
          l.add(tab[tab2[0]+1][tab2[1]]);
          l.add(tab[tab2[0]+2][tab2[1]]);
          updated=this.les_cas(l);
         
          System.out.println(tab2[0]+" "+tab2[1]);
          System.out.println(tab[tab2[0]][tab2[1]]);
          System.out.println(tab[tab2[0]+1][tab2[1]]);
          System.out.println(tab[tab2[0]+2][tab2[1]]);
          System.out.println(l.get(0));
          System.out.println(l.get(1));
          System.out.println(l.get(2));
          
          tab[tab2[0]][tab2[1]]=updated.get(0);
        tab[tab2[0]+1][tab2[1]]=updated.get(1);
        if(updated.size()>=3){
        tab[tab2[0]+2][tab2[1]]=updated.get(2);

        }
        this.afficher();

      }
      
       }         ///// fin  methode pour deplacer le robot vers en bas

    public int getNb1() {
        return nb1;
    }

    public int getNb2() {
        return nb2;
    }

       
       
     
public boolean prtie_fini(){
    boolean res=false;
    int cpt=0;
for(i=0;i<nb1;i++){
    for(int j=0;j<nb2;j++){
        if(tab[i][j].toString()=="$"){
            cpt+=1;
        }
    }
}
if(cpt==0){
    res=true;
}
return res;
    
    }

}
    
    
    
    

    
   

