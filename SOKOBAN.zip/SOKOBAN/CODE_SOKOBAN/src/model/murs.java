
package model;


public class murs extends Case{
        private int x;
    private int y;
    
    public murs(int x,int y){
        super(x,y,false,false);
    }

   
      
     public String toString(){
          return "#";

     } 
    
}
