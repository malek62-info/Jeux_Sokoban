
package model;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Collection;
import java.util.List;
import java.util.Scanner;


public class Lecture {
    private String chaine;
    private int nb_ligne;
    private int taille_ligne;
    int i=0;
    public Lecture(int nb_lign,int nb_collone,File f,String chaine1[]) throws FileNotFoundException{
        this.nb_ligne=nb_ligne;
        this.taille_ligne=nb_collone;
try{
        Scanner sc = new Scanner(f);
        while (sc.hasNextLine()){
            String text=sc.nextLine();
            chaine1[i]=text;
            i++;
      } 
      sc.close();
}catch(Exception e ){
    e.printStackTrace();
}
    }

    public String getChaine() {
        return chaine;
    }

    public int getNb_ligne() {
        return nb_ligne;
    }

    public int getTaille_ligne() {
        return taille_ligne;
    }

    
}
