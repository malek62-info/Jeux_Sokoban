
package model;


public class sol extends Case {
     private int x;
    private int y;
    
    public sol(int x,int y){
        super(x,y,false,true);
    }

   
     public String toString(){
          return "/";

     } 
    

 
}
