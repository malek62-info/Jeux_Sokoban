
package model;


public class etoile extends Case {
    
    public etoile(int x, int y) {
        super(x, y, true, false);
    
    }
    public String toString(){
        return "*";
    }
    
}
