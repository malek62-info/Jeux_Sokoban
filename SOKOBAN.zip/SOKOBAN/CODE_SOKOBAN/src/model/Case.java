
package model;


public class Case {
    private int x,y;
    private boolean deplassable;
    private boolean marche_dessus;
    public Case (int x, int y,boolean deplassble,boolean marche_dessus ){
        this.x=x;
        this.y=y;
        this.deplassable=deplassble;
        this.marche_dessus=marche_dessus;
    }
    
     public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public boolean getDeplassable() {
        return deplassable;
    }

    public void setDeplassable(boolean deplassable) {
        this.deplassable = deplassable;
    }

    public boolean isMarche_dessus() {
        return marche_dessus;
    }

    public void setMarche_dessus(boolean marche_dessus) {
        this.marche_dessus = marche_dessus;
    }
    
    
}
