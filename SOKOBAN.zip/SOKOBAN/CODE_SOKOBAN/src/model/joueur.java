
package model;

import java.util.*;


public class joueur extends Case{
    private int x;
    private int y;
    private int droit;
    private int gauche;
    private int bas;
    private int haut;
    ArrayList<Integer> list; 

    public joueur(int x,int y){
        super(x,y,true,false);
        this.list = new ArrayList<Integer>();
    }

  
     public String toString(){
          return "@";

     }
   
     
     
      public void deplacer_droit(){
        this.x=x-1;
        list.add(this.x);
    }
    public void deplacer_gauche(){
        this.x+=1;
        
        list.add(this.x);
    }
    
    public void deplacer_bas(){
        this.y-=1;
        list.add(this.y);
    }
    
    public void deplacer_haut(){
        this.y+=1;
        list.add(this.y);
    }
    
    
    
    
}
