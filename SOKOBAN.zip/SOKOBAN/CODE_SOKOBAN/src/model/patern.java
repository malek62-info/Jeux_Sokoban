
package model;


public class patern extends Case {
    private int x;
    private int y;

    public patern(int x, int y) {
        super(x, y,false,true);
    }
    
   
     public String toString(){
          return ".";

     } 
    
}
