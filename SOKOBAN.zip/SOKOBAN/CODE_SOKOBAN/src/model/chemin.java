
package model;


public class chemin extends Case {
    private int x;
    private int y;
    
    public chemin(int x,int y){
        super(x,y,false,true);
    }

  
     public String toString(){
          return " ";

     } 
    
}
