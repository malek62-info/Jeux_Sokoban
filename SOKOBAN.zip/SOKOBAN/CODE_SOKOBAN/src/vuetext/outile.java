package vuetext;

import java.io.IOException;

public class outile {

public static char lireCaractere(){
    int rep= ' ';
    int buf;
    try{
        rep = System.in.read();
        buf = rep;
        while (buf != '\n')
            buf = System.in.read();
    } 
    catch (IOException e) {};
    return (char) rep;
}

}