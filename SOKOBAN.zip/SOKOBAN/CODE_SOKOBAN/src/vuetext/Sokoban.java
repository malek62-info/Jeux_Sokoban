package vuetext;

import java.io.FileNotFoundException;


public class Sokoban  {
 
    public static void main(String[] args)  throws FileNotFoundException {
         acceulle ac =new acceulle();
            ac.aff();
            

       
         
}

    
        
      
}
