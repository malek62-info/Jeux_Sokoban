
package vuetext;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class acceulle implements ActionListener   {
     JButton b1= new JButton("parite1");
    JButton b2= new JButton("parite2");
      JButton b3= new JButton("parite3");
      JLabel jf=new JLabel("BIENVENU AU JEUX DE SOKOBAN");
           JFrame fn =new JFrame();
public acceulle(){
   
        
}
  
public void aff(){
         fn.setBounds(200, 100, 600, 500);
        b1.setBounds(160, 50, 250, 50);
        b1.addActionListener(this);
        b2.setBounds(160, 150, 250, 50);      
        b2.addActionListener(this);
         
        b3.setBounds(160, 250, 250, 50);
        b3.addActionListener(this);

        fn.getContentPane().add(b1);
        jf.setForeground(Color.red);
	jf.setFont(new Font("Tahoma", Font.BOLD, 18));
        jf.setBounds(150,350,450,50);
        fn.add(jf);

        fn.getContentPane().add(b2);
        fn.getContentPane().add(b3);

        fn.setLayout(null);
        fn.setVisible(true);
}
    @Override
    public void actionPerformed(ActionEvent e) {
if(e.getSource()==this.b1){
            File f =new File("C:\\Users\\malek\\Documents\\NetBeansProjects\\POJET_POO\\src\\vuetext\\map1.txt");
            try {
                graphique g=new graphique(f,6,9);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(Sokoban.class.getName()).log(Level.SEVERE, null, ex);
            }
      
            
        }
else{
    if(e.getSource()==this.b2){
         File f =new File("C:\\Users\\malek\\Desktop\\Sokoban _src\\map2.txt");
            try {
                graphique g=new graphique(f,13,21);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(Sokoban.class.getName()).log(Level.SEVERE, null, ex);
            }
    
    }
    else{
         File f =new File("C:\\Users\\malek\\Desktop\\Sokoban _src\\map3.txt");
            try {
                graphique g=new graphique(f,14,16);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(Sokoban.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
}
 
    
    
    
    
    
    }
    }

