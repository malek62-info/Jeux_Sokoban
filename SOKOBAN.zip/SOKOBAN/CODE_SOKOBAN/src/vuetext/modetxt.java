
package vuetext;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import model.cartes;
import java.io.FileNotFoundException;
import java.util.HashMap;



import java.util.*;
import java.util.Scanner;

import model.*;  

public class modetxt  {
   
    File f =new File("C:\\Users\\malek\\Desktop\\Sokoban _src\\map1.txt");
         int nb1=6;
         int nb2=9;
         
         String[] chaine= new String[nb1];
         
         Scanner sc=new Scanner(System.in);
         int n;
         int i; 
         cartes cart;
   
    public modetxt() throws FileNotFoundException {
        this.cart = new cartes(f,chaine,nb1,nb2);
                 cart.remplir_tab();
                 cart.afficher();
         cart.verifier_jouer();
 while(!cart.prtie_fini()){
             
             System.out.println("entrer ta derection");
             char car=new outile().lireCaractere();
             if(car=='q'){
                 cart.deplacer_robot_a_gauche();
             }
             else{
                 if(car=='z'){
                     cart.deplacer_robot_en_haut();
                 }
                 else{
                     if(car =='x'){
                     cart.deplacer_robot_en_bas();                     }
                     else{if(car=='d'){
                             cart.deplacer_robot_a_droit();
                         }
                     }
                 }
             }
         }                
         
                System.out.println("partie finie");

}                
       

    
         
         
 

      
}
