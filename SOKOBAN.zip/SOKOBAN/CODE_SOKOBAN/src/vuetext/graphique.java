
package vuetext;
import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import javax.swing.ImageIcon;
import javax.swing.*;
import model.*;
public class graphique implements  ActionListener
{
    private int x;
    private int y;
    private int nb1,nb2;
            JFrame fenetre = new JFrame();
            JLabel robot =new JLabel(new ImageIcon("C:\\Users\\malek\\Desktop\\Sokoban _src\\Haut.gif"));
            JLabel nb_pas  =new JLabel("0");
            JButton refaire =new JButton("refaire la parté");

            JLabel nb_pas1  =new JLabel("Nombre de pas Effectué");
            Object [][] t;
            File f;
            String[] chaine;
            Object  []b ;
            int i; 
            cartes cart;
            clavie cl=new clavie(cart,this);
        /////        
        public graphique(File f,int nb1, int nb2 ) throws FileNotFoundException{
        fenetre.pack();
        this.f=f;
        this.nb1=nb1;
        this.nb2=nb2;
        chaine= new String[nb1+1];
        t= new Object[nb1][nb2];
        cart= new cartes(f,chaine,nb1,nb2);     

        t=cart.remplir_tab();
        ///fenetre
        fenetre.setBounds(200,100, nb2*30+250, nb1*30+200);
        fenetre.setLayout(null);
          
         this.dessner();
        fenetre.addKeyListener(new clavie(cart,this));
        System.out.println(this.nb1);

        this.nb_pas.setBounds(nb2*30+50, 50,50,30 );
        this.nb_pas1.setBounds(nb2*30+50,15, 200,30 );
       
        fenetre.setVisible(true);
        this.refaire.setBounds(nb2*30+50, 100, 120, 30);
        this.refaire.setFocusable(false) ;
         this.refaire.addActionListener(this);
        
        ////fin de la fentre

     }
 
    

        public void dessner(){
             for(int i=0;i<nb1;i++){
             for(int j=0;j<nb2;j++){
                 if(this.t[i][j].toString()=="#"){
                    JLabel murs =new JLabel(new ImageIcon("C:\\Users\\malek\\Desktop\\Sokoban _src\\mur.gif"));
                    murs.setBounds(j*30, i*30, 30, 30);
                    fenetre.add(murs);
                    murs.setVisible(true);
                 }
                 else{
                 if(t[i][j].toString()=="$"){
                           JLabel caisse =new JLabel(new ImageIcon("C:\\Users\\malek\\Desktop\\Sokoban _src\\caisse1.gif"));
                           caisse.setBounds(j*30, i*30, 30, 30);
                           fenetre.add(caisse);

                 }
                 else{
                     if(t[i][j].toString()==" "){
                                  JLabel sol =new JLabel(new ImageIcon("C:\\Users\\malek\\Desktop\\Sokoban _src\\sol.gif"));
                                  sol.setBounds(j*30, i*30, 30, 30);
                                  fenetre.add(sol);

                         
                     }
                     else{
                     if(t[i][j].toString()=="."){
                             JLabel but =new JLabel(  new ImageIcon("C:\\Users\\malek\\Desktop\\Sokoban _src\\but.gif"));
                             but.setBounds(j*30, i*30, 30, 30);
                             fenetre.add(but);

                     }
                     else{
                            if(t[i][j].toString()=="@"){
                               robot.setBounds(j*30, i*30, 30, 30);
                               fenetre.add(robot);

                                          }
                            
                            else{
                         if(t[i][j].toString()=="*"){
                               robot.setBounds(j*30, i*30, 30, 30);
                               fenetre.add(robot);
                              

                                          }
                         else{
                                 if(t[i][j].toString()=="+"){
                            JLabel caisseg =new JLabel(new ImageIcon("C:\\Users\\malek\\Desktop\\Sokoban _src\\caisse2.gif"));

                               caisseg.setBounds(j*30, i*30, 30, 30);
                               fenetre.add(caisseg);

                        }}}}}}}}}

                  this.fenetre.getContentPane().add(this.refaire);
                  fenetre.add(nb_pas);
                  fenetre.add(nb_pas1);

        }


     @Override
    public void actionPerformed(ActionEvent e) {
       JOptionPane.showMessageDialog(fenetre, "voulez-vous vraiment refaire la partie??");
                 t=cart.remplir_tab();
          fenetre.getContentPane().removeAll();
              this.nb_pas.setText("0");
                       this.dessner();
                       fenetre.invalidate();
                       fenetre.validate();
                       fenetre.repaint();
    }
       
}

    
    

