
package vuetext;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.FileNotFoundException;
import static java.lang.System.exit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import model.*;


public class clavie implements KeyListener {
    private boolean bas,gauche,droit,haut;
    private String[] chaine= new String[15];
    private cartes t;
    private File f=new File("map3.txt");
    int nb1=0,nb2=0;

    private graphique g;
    private int nb_pas=0;

    

      public clavie(cartes t,graphique g) throws FileNotFoundException {
        this.t=t;
        this.g=g;


   

      }
     
   
    
    
    @Override
    public void keyTyped(KeyEvent e) {
    }
        @Override
    public void keyPressed(KeyEvent e) {
        int touche=e.getKeyCode();
        
        if(touche==KeyEvent.VK_UP){
            t.deplacer_robot_en_haut();
            g.robot=new JLabel(new ImageIcon("C:\\Users\\malek\\Desktop\\Sokoban _src\\Haut.gif"));
            if(t.deplaccer_en_haut()){
            this.nb_pas+=1;
            g.nb_pas.setText(String.valueOf(this.nb_pas));
            }
            t.afficher();
            System.out.println("up");
            
            

            
        }
        else{
            if(touche==KeyEvent.VK_DOWN){
              
                t.deplacer_robot_en_bas();
            g.robot=new JLabel(new ImageIcon("C:\\Users\\malek\\Desktop\\Sokoban _src\\Bas.gif"));

               System.out.println("down");
               if(t.deplaccer_en_bas()){
            this.nb_pas+=1;
            g.nb_pas.setText(String.valueOf(this.nb_pas));
            }
                
            }
            else{
                if(touche==KeyEvent.VK_LEFT){
                                    
                       t.deplacer_robot_a_gauche();
                                   t.afficher();
            g.robot=new JLabel(new ImageIcon("C:\\Users\\malek\\Desktop\\Sokoban _src\\Gauche.gif"));
             if(t.deplaccer_gauche()){
            this.nb_pas+=1;
            g.nb_pas.setText(String.valueOf(this.nb_pas));
            }
                         System.out.println("left");
                         
                }
                else{
                    if(touche==KeyEvent.VK_RIGHT){
                         t.deplacer_robot_a_droit();
                         t.afficher();          
                         g.robot=new JLabel(new ImageIcon("C:\\Users\\malek\\Desktop\\Sokoban _src\\Droite.gif"));

            if(t.deplaccer_droit()){
                this.nb_pas+=1;
                g.nb_pas.setText(String.valueOf(this.nb_pas));
            }
            System.out.println("righth");
}
                        
                    }
                }
        
        }  
                       g.fenetre.getContentPane().removeAll();
                       g.dessner();
                       g.fenetre.invalidate();
                       g.fenetre.validate();
                       g.fenetre.repaint();
                               
            

        

    }

    @Override
    public void keyReleased(KeyEvent e) {
             acceulle ace = new acceulle();
                    ace.b2.setEnabled(false);

        if(t.prtie_fini()){
         this.nb_pas=0;
         JOptionPane.showMessageDialog(g.fenetre, "paritie finier bravo.");
         g.fenetre.setVisible(false);
         ace.b2.setEnabled(true);
               

                 
             
         }
          
    }

    public void setNb_pas(int nb_pas) {
        this.nb_pas = nb_pas;
    }
    
}
        
