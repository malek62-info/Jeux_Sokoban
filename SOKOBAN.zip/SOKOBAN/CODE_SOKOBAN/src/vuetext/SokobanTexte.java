
package vuetext;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;




import java.io.FileNotFoundException;
import java.util.HashMap;



import java.util.*;
import java.util.Scanner;

import model.*;  

public class SokobanTexte {
            
   
    public static void main(String[] args) throws FileNotFoundException  {
        modetxt md=new modetxt();
                
         

}                
       
 
    }

